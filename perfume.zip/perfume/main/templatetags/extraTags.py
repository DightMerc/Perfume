from django import template

register = template.Library()

@register.simple_tag
def second(value):

    data = []
    a = 1

    while a < len(value):
        data.append(value[a])

        a += 1

    return data