from django.shortcuts import render
from .models import Product, ProductVolume

# Create your views here.
def MainView(request):
    products = Product.objects.all().filter(active=True)
    return render(request, "main/index.html", {
        'products': products,
    })


def SingleProductView(request, pk):
    product = Product.objects.all().filter(active=True).get(pk=pk)
    return render(request, "main/product-details.html", {
        'product': product,
        'mainPhoto': product.photo.all().first().photo.url,
        'photoes': product.photo.all()[1:]
    })